import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_csv(r"C:\Users\SIVAS\Downloads\ElectionData.csv")

# Display basic information
print("Shape of dataset:", df.shape)
df.info()
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic statistics:\n", df.describe())
print("\nUnique values per column:\n", df.nunique())

# Filter for contested candidates
df_contested = df[df["Category"] == "Candidates - Contested"].copy()

# Histogram of total candidates per constituency
plt.figure(figsize=(14,6))
sns.histplot(df_contested["Total"], bins=20, kde=True, color="skyblue")
plt.title("Distribution of Total Candidates per Constituency")
plt.xlabel("Number of Candidates")
plt.ylabel("Number of Constituencies")
plt.show()

# Total men and women who contested
gender_sum = df_contested[["Men", "Women"]].sum()
gender_df = pd.DataFrame({'Gender': gender_sum.index, 'Count': gender_sum.values})

plt.figure(figsize=(6,6))
sns.barplot(data=gender_df, x="Gender", y="Count", hue="Gender", palette="pastel", legend=False)
plt.title("Total Male vs Female Candidates Contested")
plt.ylabel("Number of Candidates")
plt.show()

# Total candidates per category
category_totals = df.groupby("Category")["Total"].sum().sort_values(ascending=False)
category_df = category_totals.reset_index().rename(columns={"Total": "Total", "Category": "Category"})

plt.figure(figsize=(10,6))
sns.barplot(data=category_df, x="Total", y="Category", hue="Category", palette="muted", legend=False)
plt.title("Total Candidates per Category")
plt.xlabel("Total Candidates")
plt.ylabel("Category")
plt.show()

# Heatmap for gender-wise correlation
plt.figure(figsize=(8,6))
sns.heatmap(df[["Men", "Women", "Third Gender", "Total"]].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Between Gender-wise Candidate Data")
plt.show()

df_contested.columns = df_contested.columns.str.strip()
# Boxplot for outliers - FIXED
plt.figure(figsize=(12,6))
sns.boxplot(data=df_contested, x="Category", y="Total", hue="Category", palette="Set2", legend=False)
plt.title("Outliers in Total Contested Candidates")
plt.ylabel("Total Candidates")
plt.show()

# Pie chart for top 5 states by total candidates
top_states = df.groupby("State/UT & Code")["Total"].sum().sort_values(ascending=False).head(5)

plt.figure(figsize=(7,7))
top_states.plot.pie(
    autopct='%1.1f%%',
    startangle=140,
    colors=sns.color_palette("pastel"),
    shadow=True
)
plt.title("Top 5 States/UTs by Total Candidates")
plt.ylabel("")
plt.show()




# Line plot: Top 15 constituencies by total
top_constituencies = df_contested.sort_values("Total", ascending=False).head(15)

plt.figure(figsize=(12,6))
sns.lineplot(data=top_constituencies, x="Constituency Name & Code", y="Total", marker='o', sort=False)
plt.title("Top 15 Constituencies by Total Contesting Candidates")
plt.xticks(rotation=45, ha='right')
plt.ylabel("Total Candidates")
plt.xlabel("Constituency")
plt.tight_layout()
plt.show()

# Bar plot: Top 10 states by number of constituency entries - FIXED
state_counts = df["State/UT & Code"].value_counts().head(10)
state_df = pd.DataFrame({'State': state_counts.index, 'Count': state_counts.values})

plt.figure(figsize=(10,6))
sns.barplot(data=state_df, x="Count", y="State", hue="State", palette="coolwarm", legend=False)
plt.title("Top 10 States/UTs by Number of Constituency Entries")
plt.xlabel("Count")
plt.ylabel("State/UT")
plt.show()

# Scatter plot: Women vs Total with state hue
plt.figure(figsize=(10,6))
sns.scatterplot(data=df_contested, x="Women", y="Total", hue="State/UT & Code", alpha=0.7)
plt.title("Scatter Plot of Women vs Total Contesting Candidates")
plt.xlabel("Number of Women Candidates")
plt.ylabel("Total Candidates")
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()

